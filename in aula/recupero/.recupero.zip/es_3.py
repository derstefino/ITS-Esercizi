for n in range(2,15,2):
    print(n)

for n in range(1,14,3):
    print(n)

for n in reversed(range(0,31,5)):
    print(n)

for n in range(5,46,10):
    print(n)

