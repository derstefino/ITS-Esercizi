'''Scrivere un programma che acquisisca una stringa inserita dall'utente e calcoli il numero totale di spazi presenti nella stringa.
Il risultato deve essere visualizzato in output.'''

string1:str = str(input())

print(string1.count(" "))

